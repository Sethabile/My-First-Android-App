package com.example.itja321_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

//import android.content.Context;
import android.content.Intent;
//import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
//import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    EditText firstName;
    EditText lastName;
    EditText emailText;
    EditText mobileText;
    EditText passwordText;
    TextView gender;
    RadioButton male;
    RadioButton female;
    Button createAccount;
    TextView text;
    TextView hereRegister;

    DBHelper DB;
    Pattern PASSWORD_PATTERN = Pattern.compile(".{5,}");

    /*public void validation() {

        String email = emailText.getText().toString();
        String password = passwordText.getText().toString();
        String name = firstName.getText().toString();
        String surname = lastName.getText().toString();
        //mobile number, gender

        //Checks for empty fields
        if (email.equals("") || password.equals("") || name.equals("") || surname.equals("")) {
            Toast.makeText(RegisterActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();

        }
        //Validates email
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(RegisterActivity.this, "Enter valid email", Toast.LENGTH_LONG).show();

        }

        //Checks email and password from database
        Boolean checkemailpass = DB.checkemailpassword(email, password);
        if (checkemailpass == true) {
            Toast.makeText(RegisterActivity.this, "Email already exists", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);

        }
        //validates password
        if (!PASSWORD_PATTERN.matcher(password).matches()) {
            Toast.makeText(RegisterActivity.this, "Password has to be at least 5 characters", Toast.LENGTH_LONG).show();

        }

        Boolean addUser = DB.checkemailpassword(email, password);
        if (addUser == true) {
            Toast.makeText(RegisterActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
        }

    }*/






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        ActionBar actionBar = getSupportActionBar();
        assert null != actionBar;
        actionBar.hide();

        firstName = (EditText) findViewById(R.id.editTextTextPersonName2);
        lastName = (EditText) findViewById(R.id.editTextTextPersonName3);
        mobileText = (EditText) findViewById(R.id.editTextPhone);
        emailText = (EditText) findViewById(R.id.editTextTextEmailAddress2);
        passwordText = (EditText) findViewById(R.id.editTextTextPassword2);
        gender = (TextView) findViewById(R.id.textView5);
        male = (RadioButton) findViewById(R.id.radioButton);
        female = (RadioButton) findViewById(R.id.radioButton2);
        createAccount = (Button) findViewById(R.id.button2);
        text = (TextView) findViewById(R.id.textView6);
        hereRegister = (TextView) findViewById(R.id.textView7);

        DB = new DBHelper(this);

        hereRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);

            }

        });

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view1) {

                getUserDetails();
                //validation();
                Intent intent1 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent1);

            }

        });

    }

    private void getUserDetails() {

        String email = emailText.getText().toString();
        String password = passwordText.getText().toString();
        String name = firstName.getText().toString();
        String surname = lastName.getText().toString();
        //mobile number, gender

        //Checks for empty fields
        if (email.equals("") || password.equals("") || name.equals("") || surname.equals("")) {
            Toast.makeText(RegisterActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();

        }
        else {

            boolean insertedData = DB.getUserDetails(
                    emailText.getText().toString(),
                    passwordText.getText().toString(),
                    firstName.getText().toString(),
                    lastName.getText().toString(),
                    Long.parseLong(mobileText.getText().toString().trim())


                    //gender.getText().toString()
            );
            if (insertedData = true)
                Toast.makeText(RegisterActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(RegisterActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
        }

        //Validates email
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(RegisterActivity.this, "Enter valid email", Toast.LENGTH_LONG).show();

        }

        //Checks email and password from database
        Boolean checkemailpass = DB.checkemailpassword(email, password);
        if (checkemailpass == true) {
            Toast.makeText(RegisterActivity.this, "Email already exists", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);

        }
        //validates password
        if (!PASSWORD_PATTERN.matcher(password).matches()) {
            Toast.makeText(RegisterActivity.this, "Password has to be at least 5 characters", Toast.LENGTH_LONG).show();

        }

        Boolean getUserDetails = DB.checkemailpassword(email, password);
        if (getUserDetails == true) {
            Toast.makeText(RegisterActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
        }



    }





    /*private void AddUser(String newUser){

        createAccount.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean insertedData = DB.addUser(
                                emailText.getText().toString(),
                                passwordText.getText().toString(),
                                firstName.getText().toString(),
                                lastName.getText().toString(),
                                mobileNum = Long.parseLong(mobileText.getText().toString().trim())

                                //gender.getText().toString()
                        );
                        if (insertedData = true)
                            Toast.makeText(RegisterActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                        else
                            Toast.makeText(RegisterActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                    }
        });


        boolean insertData = DB.addUser(newUser);

        if (insertData) {
            Toast.makeText(RegisterActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(RegisterActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
    }*/





}