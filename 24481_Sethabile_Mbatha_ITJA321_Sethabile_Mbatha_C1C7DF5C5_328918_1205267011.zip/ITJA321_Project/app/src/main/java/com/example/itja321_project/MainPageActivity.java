package com.example.itja321_project;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainPageActivity extends AppCompatActivity {



    Button viewAC;
    Button transferBA;
    Button logout;
    TextView nameWelcome;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        ActionBar actionBar = getSupportActionBar();
        assert null != actionBar;
        actionBar.hide();

        viewAC = (Button) findViewById(R.id.button);
        transferBA = (Button) findViewById(R.id.button4);
        logout = (Button) findViewById(R.id.button5);
        nameWelcome = (TextView) findViewById(R.id.textView19);

        //Name on welcome text
        SQLiteDatabase MyDB = getApplicationContext().openOrCreateDatabase("Login.db", Context.MODE_PRIVATE, null);
        Cursor cursor = MyDB.rawQuery("select * from users", null);
        StringBuffer buffer = new StringBuffer();
        while (cursor.moveToNext()) {
            //buffer.append("Name" + cursor.getString(2) + "\n");
            nameWelcome.setText(buffer.append("name" + cursor.getString(2)));
        }


        viewAC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), ViewAccountBalanceActivity.class);
                startActivity(intent);
            }
        });
        transferBA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view1) {
                Intent intent = new Intent(getApplicationContext(), TransferBetweenAccountsActivity.class);
                startActivity(intent);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                Toast.makeText(MainPageActivity.this, "You have logged out", Toast.LENGTH_SHORT).show();
            }
        });



    }
}