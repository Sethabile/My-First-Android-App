package com.example.itja321_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class TransferBetweenAccountsActivity extends AppCompatActivity {

    Spinner dropdownmenu;
    TextView current;
    TextView savings;
    Button transferButton;
    EditText amount;
    String accountFrom = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer_between_accounts);

        ActionBar actionBar = getSupportActionBar();
        assert null != actionBar;
        actionBar.hide();

        dropdownmenu = (Spinner) findViewById(R.id.spinner2);
        current = (TextView) findViewById(R.id.textView25);
        savings = (TextView) findViewById(R.id.textView26);
        amount = (EditText) findViewById(R.id.editTextAmount);
        transferButton = (Button) findViewById(R.id.button6);

        List<String> list = new ArrayList<>();
        list.add("Current to Savings");
        list.add("Savings to Current");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        dropdownmenu.setAdapter(adapter);

        SQLiteDatabase MyDB = getApplicationContext().openOrCreateDatabase("Login.db", Context.MODE_PRIVATE, null);
        Cursor cursor = MyDB.rawQuery("select * from users", null);
        StringBuffer buffer = new StringBuffer();
        while (cursor.moveToNext()) {

            current.setText(buffer.append("currentAB" + cursor.getString(6)));
            savings.setText(buffer.append("savingsAB" + cursor.getString(7)));

        }

        //MyDB = this.getWritableDatabase();
        final TextView email = new TextView(this);
        Cursor cursor1= MyDB.rawQuery("select * from users where email = ?", new String[] {String.valueOf(email)});

        while(cursor1.moveToNext()){
            current.setText(cursor1.getString(6));
            savings.setText(cursor1.getString(7));

        }

        transferButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer currentBalance = Integer.parseInt(current.getText().toString());
                Integer savingsBalance = Integer.parseInt(savings.getText().toString());

                Integer newCurrent = null;
                Integer newSavings = null;

                if (accountFrom.equals("Savings to Current")) {
                    newCurrent = currentBalance + Integer.parseInt(amount.getText().toString());
                    newSavings = savingsBalance - Integer.parseInt(amount.getText().toString());
                }
                else {
                    newCurrent =  currentBalance - Integer.parseInt(amount.getText().toString());
                    newSavings = savingsBalance + Integer.parseInt(amount.getText().toString());
                }

                Toast.makeText(TransferBetweenAccountsActivity.this, "Transferred successfully", Toast.LENGTH_SHORT).show();

            }
        });


    }
}