package com.example.itja321_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.util.Log;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DBNAME = "Login.db";
    public static final String TABLE_NAME = "users";

    public DBHelper(Context context) {
        super(context, "Login.db", null,1);
    }


    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table users(email TEXT primary key, password TEXT, firstName TEXT, lastName TEXT, mobile LONG, gender BOOL, currentAB INT, savingsAB INT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int oldVersion, int newVersion) {
        MyDB.execSQL("drop Table if exists users");
    }

    //Inserting into database
    public Boolean getUserDetails(String email, String password, String firstName, String lastName, Long mobile/*, Boolean gender*/){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("first name", firstName);
        contentValues.put("last Name", lastName);
        contentValues.put("mobile", mobile);

        //contentValues.put("gender", gender);

        //Log.d(TAG, "add data " + email + password + firstName + lastName + mobile + gender + "to" + TABLE_NAME);

        long result = MyDB.insert("users",null, contentValues);

        if (result == -1){
            return false;
        }
        else
            return true;

    }

    public boolean money(Integer currentAB, Integer savingsAB){

        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("current account balance", currentAB);
        contentValues.put("savings account balance", savingsAB);


        MyDB.execSQL("insert into users(currentAB) values ('100')");
        MyDB.execSQL("insert into users(currentAB) values ('200')");




        long result = MyDB.insert("users",null, contentValues);

        if (result == -1){
            return false;
        }
        else
            return true;
    }

    public boolean updateBalance(String email, String password, String firstName, String lastName, Long mobile/*, Boolean gender*/){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues1 = new ContentValues();

        contentValues1.put("email", email);
        contentValues1.put("password", password);
        contentValues1.put("first name", firstName);
        contentValues1.put("last Name", lastName);
        contentValues1.put("mobile", mobile);




        long result = MyDB.insert("users",null, contentValues1);

        if (result == -1){
            return false;
        }
        else
            return true;

    }

    //Check if email exists
    public Boolean checkemail(String email){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from users where email = ?", new String[] {email});

        if (cursor.getCount() > 0){
            return true;
        }
        else
            return false;

    }

    public Boolean checkemailpassword(String email, String password){
        SQLiteDatabase MyDB =  this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where email = ? and password = ?", new String[] {email, password});

        if (cursor.getCount() > 0){
            return true;
        }
        else
            return false;

    }

    /*
    public String getUserDetails() throws SQLException {



    }*/



}
