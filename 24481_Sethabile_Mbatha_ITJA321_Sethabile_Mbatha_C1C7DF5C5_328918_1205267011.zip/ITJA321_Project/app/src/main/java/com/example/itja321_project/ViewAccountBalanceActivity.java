package com.example.itja321_project;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

public class ViewAccountBalanceActivity extends AppCompatActivity {

    
    TextView holderName;
    TextView holderSurname;
    TextView currentAcc;
    TextView savingsAcc;

    


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_account_balance);

        ActionBar actionBar = getSupportActionBar();
        assert null != actionBar;
        actionBar.hide();


        holderName = (TextView) findViewById(R.id.textView20);
        holderSurname = (TextView) findViewById(R.id.textView21);
        currentAcc = (TextView) findViewById(R.id.textView22);
        savingsAcc = (TextView) findViewById(R.id.textView23);
        


        SQLiteDatabase MyDB = getApplicationContext().openOrCreateDatabase("Login.db", Context.MODE_PRIVATE, null);
        Cursor cursor = MyDB.rawQuery("select * from users", null);
        StringBuffer buffer = new StringBuffer();
        while (cursor.moveToNext()) {
            
            holderName.setText(buffer.append("firstName" + cursor.getString(2)));
            holderSurname.setText(buffer.append("lastName" + cursor.getString(3)));
            currentAcc.setText(buffer.append("currentAB" + cursor.getString(6)));
            savingsAcc.setText(buffer.append("savingsAB" + cursor.getString(7)));
            
        }
        
        

    }

    



    /*
    @Override
    public boolean onSupportNavigateUp(){
        onBackPressed();
        return(true);
    }*/



}