package com.example.itja321_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
//import android.view.View;
import android.util.Patterns;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.regex.Pattern;


public class MainActivity extends AppCompatActivity {

    EditText textEmail;
    EditText textPassword;
    Button loginButton;
    TextView register;
    ImageView image;
    TextView here;

    DBHelper DB;
    Pattern PASSWORD_PATTERN = Pattern.compile(".{5,}");



    public void validation() {
        String email = textEmail.getText().toString();
        String pass = textPassword.getText().toString();

        //checks for empty fields
        if (email.equals("") || pass.equals("")) {
            Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();

        }
        //validates email
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(MainActivity.this, "Enter valid email", Toast.LENGTH_LONG).show();

        }
        //validates password
        if (!PASSWORD_PATTERN.matcher(pass).matches()) {
            Toast.makeText(MainActivity.this, "Password has to be at least 5 characters", Toast.LENGTH_LONG).show();

        }
        //checks email and password in database
        Boolean checkemailpass = DB.checkemailpassword(email, pass);
        if (checkemailpass == true) {
            Toast.makeText(MainActivity.this, "Successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        }
/*
        else {
            Toast.makeText(MainActivity.this, "Successful", Toast.LENGTH_SHORT).show();

        }*/
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        assert null != actionBar;
        actionBar.hide();

        textEmail = (EditText) findViewById(R.id.editTextTextEmailAddress3);
        textPassword = (EditText) findViewById(R.id.editTextTextPassword3);
        loginButton = (Button) findViewById(R.id.button3);
        register = (TextView) findViewById(R.id.textView9);
        image = (ImageView) findViewById(R.id.imageView2);
        here = (TextView) findViewById(R.id.textView10);
        //new View.OnClickListener()

        /*here.setOnClickListener(view -> {

            Intent hereIntent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(hereIntent);
        });*/

        DB = new DBHelper(this);

        here.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);

            }

        });

        loginButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view1) {

                validation();

                Intent intent = new Intent(getApplicationContext(), MainPageActivity.class);
                startActivity(intent);

                SQLiteDatabase MyDB = getApplicationContext().openOrCreateDatabase("Login.db", Context.MODE_PRIVATE, null);
                Cursor cursor = MyDB.rawQuery("select * from users", null);
                /*if (cursor.getCount()==()) {
                    //if no record is found then
                }*/
                /*
                StringBuffer buffer = new StringBuffer();
                while (cursor.moveToNext()) {
                    buffer.append("Name" + cursor.getString(2) + "\n");
                }*/


            }

        });



    }

    
    
    
}